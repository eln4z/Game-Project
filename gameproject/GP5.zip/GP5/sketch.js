/*
    The Game Project Part 4 - Character Interaction
*/

var gameChar_x;
var gameChar_y;
var floorPos_y;
var canyon;
var collectable;
var flagpole;
var isPlummeting;

//interaction code//
var isLeft;
var isRight;
var isFalling;

function setup() {
    createCanvas(1024, 576);
    floorPos_y = height * 3 / 4;
    gameChar_x = width / 2;
    gameChar_y = floorPos_y;

    canyon = { x_pos: 200, width: 150 };

    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    collectable = {
        x_pos: 500,
        y_pos: floorPos_y,
        size: 50,
        isFound: false
    };
    flagpole = { x_pos: 100, y_pos: floorPos_y, isReached: false };
}

function draw() {

    ///////////DRAWING CODE//////////

    background(100, 155, 255);

    noStroke();
    fill(0, 155, 0);
    rect(0, floorPos_y, width, height - floorPos_y);
    noStroke();
    fill(92, 40, 0);
    rect(canyon.x_pos, floorPos_y, canyon.width, height - floorPos_y);

    // collectable item
    let distanceToCollectable = dist(gameChar_x, gameChar_y, collectable.x_pos + 364, collectable.y_pos);
    if (distanceToCollectable < 20 && !collectable.isFound) {
        collectable.isFound = true;
    }
    if (!collectable.isFound) {
        fill(12, 124, 6);
        rect(collectable.x_pos + 346, collectable.y_pos + 5, 5, 30);
        fill(234, 230, 14);
        ellipse(collectable.x_pos + 364, collectable.y_pos, 20, 20);
        ellipse(collectable.x_pos + 347, collectable.y_pos + 12, 20, 20);
        ellipse(collectable.x_pos + 347, collectable.y_pos - 10, 20, 20);
        ellipse(collectable.x_pos + 335, collectable.y_pos, 20, 20);
        fill(2, 0, 0);
        ellipse(collectable.x_pos + 350, collectable.y_pos + 2, 15, 15);

    }

    // flagpole
    let distanceToFlagpole = dist(gameChar_x, gameChar_y, flagpole.x_pos, flagpole.y_pos);
    if (distanceToFlagpole < 20) {
        flagpole.isReached = true;
        console.log("Flagpole reached!");
    }

    if (!flagpole.isReached) {
        stroke(0)
        strokeWeight(2)
        line(flagpole.x_pos, flagpole.y_pos, flagpole.x_pos, 288)
        noStroke()
        fill(242, 34, 19)
        rect(flagpole.x_pos + 1, flagpole.y_pos - 146, 50, 30)
        fill(39, 186, 31)
        rect(flagpole.x_pos + 1, flagpole.y_pos - 146, 50, 10)
        fill(255, 255, 255)
        rect(flagpole.x_pos + 1, flagpole.y_pos - 137, 50, 10)

    } else {
        stroke(0)
        strokeWeight(2)
        line(flagpole.x_pos, flagpole.y_pos, flagpole.x_pos, 288)
        noStroke()
        fill(235, 52, 195)
        rect(flagpole.x_pos + 1, flagpole.y_pos - 146, 50, 30)
    }

   // The game character
    if (isLeft && isFalling) {
        // Add your jumping-left code
        fill(37, 234, 241);
        rect(gameChar_x - 10, gameChar_y - 52, 18, 30);  // Body
        rect(gameChar_x - 9.8, gameChar_y - 72, 13, 20); // Head
        fill(214, 234, 37);
        rect(gameChar_x + 3, gameChar_y - 72, 5, 20);  // Ear
        fill(214, 234, 37);
        rect(gameChar_x - 25, gameChar_y - 45, 25, 5); // Right hand
        quad(gameChar_x - 10, gameChar_y - 15, gameChar_x + 2, gameChar_y - 15, gameChar_x + 3, gameChar_y - 22, gameChar_x - 7, gameChar_y - 22); // Leg 
        quad(gameChar_x - 3, gameChar_y - 5, gameChar_x + 9, gameChar_y - 5, gameChar_x + 1, gameChar_y - 17, gameChar_x - 10, gameChar_y - 17); // Leg
        fill(224, 139, 232);
        rect(gameChar_x - 9, gameChar_y - 72, 5, 5); // Head line
        rect(gameChar_x - 6, gameChar_y - 7, 15, 5); // Shoes
        fill(224, 139, 232);
        fill(250, 250, 250);
        ellipse(gameChar_x - 5, gameChar_y - 62, 6, 6); // Eye
        fill(0, 0, 0);
        ellipse(gameChar_x - 5, gameChar_y - 62, 3, 3); // Eye
        rect(gameChar_x - 9, gameChar_y - 55, 4, 3); // Lips
        
        
    } else if (isRight && isFalling) {
        // Add your jumping-right code
        fill(37, 234, 241);
        rect(gameChar_x - 10, gameChar_y - 52, 18, 30);  // Body
        rect(gameChar_x - 6, gameChar_y - 72, 13, 20); // Head
        fill(214, 234, 37);
        rect(gameChar_x - 10, gameChar_y - 72, 5, 20);  // Ear
        fill(214, 234, 37);
        rect(gameChar_x, gameChar_y - 45, 25, 5); // Right hand
        quad(gameChar_x, gameChar_y - 15, gameChar_x + 12, gameChar_y - 15, gameChar_x + 5, gameChar_y - 22, gameChar_x - 5, gameChar_y - 22); // Leg
        quad(gameChar_x - 3, gameChar_y - 5, gameChar_x + 9, gameChar_y - 5, gameChar_x + 11, gameChar_y - 17, gameChar_x, gameChar_y - 17); // Leg
        fill(224, 139, 232);
        rect(gameChar_x + 1, gameChar_y - 72, 5, 5); // Head line
        rect(gameChar_x - 3, gameChar_y - 7, 15, 5); // Shoes
        fill(250, 250, 250);
        ellipse(gameChar_x + 1, gameChar_y - 62, 6, 6); // Eye
        fill(0, 0, 0);
        ellipse(gameChar_x + 1, gameChar_y - 62, 3, 3); // Eye
        rect(gameChar_x + 1, gameChar_y - 55, 4, 3); // Lips
    } else if (isLeft) {
        // Add your walking left code
        fill(37, 234, 241);
        rect(gameChar_x - 10, gameChar_y - 52, 18, 40);  // Body
        rect(gameChar_x - 9.8, gameChar_y - 72, 13, 20); // Head
        fill(214, 234, 37);
        rect(gameChar_x + 3, gameChar_y - 72, 5, 20);  // Ear
        fill(224, 139, 232);
        rect(gameChar_x - 9, gameChar_y - 72, 5, 5); // Head line
        fill(214, 234, 37);
        rect(gameChar_x - 7, gameChar_y - 45, 5, 25); // Right hand
        quad(gameChar_x - 13, gameChar_y, gameChar_x - 1, gameChar_y, gameChar_x + 2, gameChar_y - 12, gameChar_x - 8, gameChar_y - 12); // Leg
        quad(gameChar_x, gameChar_y, gameChar_x + 12, gameChar_y, gameChar_x + 5, gameChar_y - 12, gameChar_x - 5, gameChar_y - 12); // Leg
        fill(224, 139, 232);
        rect(gameChar_x - 17, gameChar_y, 15, 5); // Left shoes
        rect(gameChar_x + 0.5, gameChar_y, 15, 5); // Right shoes
        fill(250, 250, 250);
        ellipse(gameChar_x - 5, gameChar_y - 62, 6, 6); // Eye
        fill(0, 0, 0);
        ellipse(gameChar_x - 5, gameChar_y - 62, 3, 3); // Eye
        rect(gameChar_x - 9, gameChar_y - 55, 4, 3); // Lips
    } else if (isRight) {
        // Add your walking right code
        fill(37, 234, 241);
        rect(gameChar_x - 10, gameChar_y - 52, 18, 40);  // Body
        rect(gameChar_x - 6, gameChar_y - 72, 13, 20); // Head
        fill(214, 234, 37);
        rect(gameChar_x - 10, gameChar_y - 72, 5, 20);  // Ear
        fill(224, 139, 232);
        rect(gameChar_x + 1, gameChar_y - 72, 5, 5); // Head line
        fill(214, 234, 37);
        rect(gameChar_x, gameChar_y - 45, 5, 25); // Right hand
        quad(gameChar_x, gameChar_y, gameChar_x + 12, gameChar_y, gameChar_x + 5, gameChar_y - 12, gameChar_x - 5, gameChar_y - 12); // Leg
        quad(gameChar_x - 13, gameChar_y, gameChar_x - 1, gameChar_y, gameChar_x + 2, gameChar_y - 12, gameChar_x - 8, gameChar_y - 12); // Leg
        fill(224, 139, 232);
        rect(gameChar_x - 17, gameChar_y, 15, 5); // Left shoes
        rect(gameChar_x + 0.5, gameChar_y, 15, 5); // Right shoes
        fill(250, 250, 250);
        ellipse(gameChar_x + 1, gameChar_y - 62, 6, 6); // Eye
        fill(0, 0, 0);
        ellipse(gameChar_x + 1, gameChar_y - 62, 3, 3); // Eye
        rect(gameChar_x + 1, gameChar_y - 55, 4, 3); // Lips
    } else if (isFalling || isPlummeting) {
        // Add your jumping facing forwards code
        fill(214, 234, 37);
        ellipse(gameChar_x - 10, gameChar_y - 63, 10, 20); // Left ear
        ellipse(gameChar_x + 7, gameChar_y - 63, 10, 20);  // Right ear
        fill(37, 234, 241);
        rect(gameChar_x - 16, gameChar_y - 52, 30, 30);  // Body
        rect(gameChar_x - 9.8, gameChar_y - 72, 17, 20); // Head
        fill(224, 139, 232);
        rect(gameChar_x - 6.8, gameChar_y - 72, 10, 5); // Head line
        fill(214, 234, 37);
        rect(gameChar_x - 21, gameChar_y - 45, 5, 25); // Left hand
        rect(gameChar_x + 14.3, gameChar_y - 45, 5, 25); // Right hand
        rect(gameChar_x - 10, gameChar_y - 24, 8, 13); // Left leg
        rect(gameChar_x + 2, gameChar_y - 24, 8, 13); // Right leg
        fill(224, 139, 232);
        rect(gameChar_x - 17, gameChar_y - 15, 15, 5); // Left shoes
        rect(gameChar_x + 0.5, gameChar_y - 15, 15, 5); // Right shoes
        fill(250, 250, 250);
        ellipse(gameChar_x - 5, gameChar_y - 62, 6, 6); // Left eye
        ellipse(gameChar_x + 2, gameChar_y - 62, 6, 6); // Right eye
        fill(0, 0, 0);
        ellipse(gameChar_x - 5, gameChar_y - 62, 3, 3); // Left eye
        ellipse(gameChar_x + 2, gameChar_y - 62, 3, 3); // Right eye
        rect(gameChar_x - 5, gameChar_y - 55, 8, 3); // Lips
        rect(gameChar_x - 2, gameChar_y - 6, 3, 16); // Middle black line
        rect(gameChar_x + 6, gameChar_y - 8.5, 3, 16); // Right black line
        rect(gameChar_x - 10, gameChar_y - 8.5, 3, 16); // Left black line
    } else {
        // Add your standing front-facing code
        fill(214, 234, 37);
        ellipse(gameChar_x - 10, gameChar_y - 63, 10, 20); // Left ear
        ellipse(gameChar_x + 7, gameChar_y - 63, 10, 20);  // Right ear
        fill(37, 234, 241);
        rect(gameChar_x - 16, gameChar_y - 52, 30, 40);  // Body
        rect(gameChar_x - 9.8, gameChar_y - 72, 17, 20); // Head
        fill(224, 139, 232);
        rect(gameChar_x - 6.8, gameChar_y - 72, 10, 5); // Head line
        fill(214, 234, 37);
        rect(gameChar_x - 21, gameChar_y - 45, 5, 25); // Left hand
        rect(gameChar_x + 14.3, gameChar_y - 45, 5, 25); // Right hand
        rect(gameChar_x - 10, gameChar_y - 12, 8, 16); // Left leg
        rect(gameChar_x + 2, gameChar_y - 12, 8, 16); // Right leg
        fill(224, 139, 232);
        rect(gameChar_x - 17, gameChar_y, 15, 5); // Left shoes
        rect(gameChar_x + 0.5, gameChar_y, 15, 5); // Right shoes
        fill(250, 250, 250);
        ellipse(gameChar_x - 5, gameChar_y - 62, 6, 6); // Left eye
        ellipse(gameChar_x + 2, gameChar_y - 62, 6, 6); // Right eye
        fill(0, 0, 0);
        ellipse(gameChar_x - 5, gameChar_y - 62, 3, 3); //left eye
        ellipse(gameChar_x + 2, gameChar_y - 62, 3, 3); //right eye
        rect(gameChar_x - 5, gameChar_y - 55, 8, 3); //lips
    }
    
    if(gameChar_x > canyon.x_pos && gameChar_x < canyon.x_pos + canyon.width && gameChar_y >= floorPos_y){
        isPlummeting = true;
    }
    if(isPlummeting){
        
        gameChar_y += 10;
    }
    
    if(isLeft==true){
        gameChar_x-=5;
    }
    
    else if(isRight==true){
        gameChar_x+=5;
    }
   
    if (gameChar_y < floorPos_y){
        gameChar_y += 1
        isFalling = true;
    } 
    
    else {
        isFalling = false;
    }


    ///////////INTERACTION CODE//////////
}

function keyPressed() {
    console.log("keyPressed: " + key);
    console.log("keyPressed: " + keyCode);

   

    if (key == "a") {
        isLeft = true;
    } 
    
    else if (key == "d") {
        isRight = true;
    }
    
    else if (key == "w" && !isFalling && !isPlummeting) {
        gameChar_y -= 100;
    }
}

function keyReleased() {
    console.log("keyReleased: " + key);
    console.log("keyReleased: " + keyCode);

    if (key == "a") {
        isLeft = false;
    } 
    
    else if (key == "d") {
        isRight = false;
    }
}
